To install the native application:




  1. Extract this downloaded ZIP file in a local directory.



  2. Double-click on "install.bat".



  3. Wait for the script to display the successful message.




To uninstall the native application:



  1. Double-click on "uninstall.bat".



  2. Wait for the script to display the successful message.





Note: these scripts do not need administrator permission anymore!







Installation Guide (skip the administrator permission part):



  https://www.youtube.com/watch?v=yZAoy8SOd7o
